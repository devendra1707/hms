package com.liferay.hms.second.opinion.web.constants;

/**
 * @author dell
 */
public class SecondOpinionPortletKeys {

	public static final String SECONDOPINION =
		"com_liferay_hms_second_opinion_web_SecondOpinionPortlet";

}