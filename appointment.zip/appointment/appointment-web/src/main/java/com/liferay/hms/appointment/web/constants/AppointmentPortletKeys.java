package com.liferay.hms.appointment.web.constants;

/**
 * @author dell
 */
public class AppointmentPortletKeys {

	public static final String APPOINTMENT =
		"com_liferay_hms_appointment_web_AppointmentPortlet";

}