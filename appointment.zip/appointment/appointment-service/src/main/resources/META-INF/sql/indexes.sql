create index IX_D9F9F4E3 on hms1_Appointment (age[$COLUMN_LENGTH:75$], deleted);
create index IX_7FFA546C on hms1_Appointment (country[$COLUMN_LENGTH:75$], deleted);
create index IX_C9102F66 on hms1_Appointment (email[$COLUMN_LENGTH:75$], deleted);
create index IX_53CE6988 on hms1_Appointment (groupId, deleted);
create index IX_DA2DA2E1 on hms1_Appointment (name[$COLUMN_LENGTH:75$], deleted);
create index IX_5FD3AD9C on hms1_Appointment (name[$COLUMN_LENGTH:75$], email[$COLUMN_LENGTH:75$], country[$COLUMN_LENGTH:75$], age[$COLUMN_LENGTH:75$], deleted);
create index IX_8B9903DD on hms1_Appointment (uuid_[$COLUMN_LENGTH:75$], companyId);
create unique index IX_705ADD9F on hms1_Appointment (uuid_[$COLUMN_LENGTH:75$], groupId);

create index IX_C060FC8E on hms_Appointment (age[$COLUMN_LENGTH:75$], deleted);
create index IX_46EF8E97 on hms_Appointment (country[$COLUMN_LENGTH:1024$], deleted);
create index IX_B1D3F851 on hms_Appointment (email[$COLUMN_LENGTH:75$], deleted);
create index IX_1AC3A3B3 on hms_Appointment (groupId, deleted);
create index IX_C0A79096 on hms_Appointment (name[$COLUMN_LENGTH:75$], deleted);
create index IX_594CD307 on hms_Appointment (name[$COLUMN_LENGTH:75$], email[$COLUMN_LENGTH:75$], country[$COLUMN_LENGTH:1024$], age[$COLUMN_LENGTH:75$], deleted);
create index IX_528E3E08 on hms_Appointment (uuid_[$COLUMN_LENGTH:75$], companyId);
create unique index IX_591EA68A on hms_Appointment (uuid_[$COLUMN_LENGTH:75$], groupId);