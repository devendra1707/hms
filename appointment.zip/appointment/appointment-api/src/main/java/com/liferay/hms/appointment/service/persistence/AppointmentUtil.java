/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.hms.appointment.service.persistence;

import com.liferay.hms.appointment.model.Appointment;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The persistence utility for the appointment service. This utility wraps <code>com.liferay.hms.appointment.service.persistence.impl.AppointmentPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author devendra
 * @see AppointmentPersistence
 * @generated
 */
public class AppointmentUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(Appointment appointment) {
		getPersistence().clearCache(appointment);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, Appointment> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Appointment> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Appointment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Appointment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static Appointment update(Appointment appointment) {
		return getPersistence().update(appointment);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static Appointment update(
		Appointment appointment, ServiceContext serviceContext) {

		return getPersistence().update(appointment, serviceContext);
	}

	/**
	 * Returns all the appointments where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching appointments
	 */
	public static List<Appointment> findByUuid(String uuid) {
		return getPersistence().findByUuid(uuid);
	}

	/**
	 * Returns a range of all the appointments where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @return the range of matching appointments
	 */
	public static List<Appointment> findByUuid(
		String uuid, int start, int end) {

		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	 * Returns an ordered range of all the appointments where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the appointments where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<Appointment> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByUuid(
			uuid, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first appointment in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByUuid_First(
			String uuid, OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	 * Returns the first appointment in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByUuid_First(
		String uuid, OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByUuid_Last(
			String uuid, OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByUuid_Last(
		String uuid, OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	 * Returns the appointments before and after the current appointment in the ordered set where uuid = &#63;.
	 *
	 * @param appointmentId the primary key of the current appointment
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next appointment
	 * @throws NoSuchAppointmentException if a appointment with the primary key could not be found
	 */
	public static Appointment[] findByUuid_PrevAndNext(
			long appointmentId, String uuid,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByUuid_PrevAndNext(
			appointmentId, uuid, orderByComparator);
	}

	/**
	 * Removes all the appointments where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 */
	public static void removeByUuid(String uuid) {
		getPersistence().removeByUuid(uuid);
	}

	/**
	 * Returns the number of appointments where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching appointments
	 */
	public static int countByUuid(String uuid) {
		return getPersistence().countByUuid(uuid);
	}

	/**
	 * Returns the appointment where uuid = &#63; and groupId = &#63; or throws a <code>NoSuchAppointmentException</code> if it could not be found.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByUUID_G(String uuid, long groupId)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByUUID_G(uuid, groupId);
	}

	/**
	 * Returns the appointment where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByUUID_G(String uuid, long groupId) {
		return getPersistence().fetchByUUID_G(uuid, groupId);
	}

	/**
	 * Returns the appointment where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByUUID_G(
		String uuid, long groupId, boolean useFinderCache) {

		return getPersistence().fetchByUUID_G(uuid, groupId, useFinderCache);
	}

	/**
	 * Removes the appointment where uuid = &#63; and groupId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the appointment that was removed
	 */
	public static Appointment removeByUUID_G(String uuid, long groupId)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().removeByUUID_G(uuid, groupId);
	}

	/**
	 * Returns the number of appointments where uuid = &#63; and groupId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the number of matching appointments
	 */
	public static int countByUUID_G(String uuid, long groupId) {
		return getPersistence().countByUUID_G(uuid, groupId);
	}

	/**
	 * Returns all the appointments where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the matching appointments
	 */
	public static List<Appointment> findByUuid_C(String uuid, long companyId) {
		return getPersistence().findByUuid_C(uuid, companyId);
	}

	/**
	 * Returns a range of all the appointments where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @return the range of matching appointments
	 */
	public static List<Appointment> findByUuid_C(
		String uuid, long companyId, int start, int end) {

		return getPersistence().findByUuid_C(uuid, companyId, start, end);
	}

	/**
	 * Returns an ordered range of all the appointments where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByUuid_C(
		String uuid, long companyId, int start, int end,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().findByUuid_C(
			uuid, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the appointments where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByUuid_C(
		String uuid, long companyId, int start, int end,
		OrderByComparator<Appointment> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByUuid_C(
			uuid, companyId, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first appointment in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByUuid_C_First(
			String uuid, long companyId,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByUuid_C_First(
			uuid, companyId, orderByComparator);
	}

	/**
	 * Returns the first appointment in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByUuid_C_First(
		String uuid, long companyId,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByUuid_C_First(
			uuid, companyId, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByUuid_C_Last(
			String uuid, long companyId,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByUuid_C_Last(
			uuid, companyId, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByUuid_C_Last(
		String uuid, long companyId,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByUuid_C_Last(
			uuid, companyId, orderByComparator);
	}

	/**
	 * Returns the appointments before and after the current appointment in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param appointmentId the primary key of the current appointment
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next appointment
	 * @throws NoSuchAppointmentException if a appointment with the primary key could not be found
	 */
	public static Appointment[] findByUuid_C_PrevAndNext(
			long appointmentId, String uuid, long companyId,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByUuid_C_PrevAndNext(
			appointmentId, uuid, companyId, orderByComparator);
	}

	/**
	 * Removes all the appointments where uuid = &#63; and companyId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 */
	public static void removeByUuid_C(String uuid, long companyId) {
		getPersistence().removeByUuid_C(uuid, companyId);
	}

	/**
	 * Returns the number of appointments where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the number of matching appointments
	 */
	public static int countByUuid_C(String uuid, long companyId) {
		return getPersistence().countByUuid_C(uuid, companyId);
	}

	/**
	 * Returns all the appointments where name = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param deleted the deleted
	 * @return the matching appointments
	 */
	public static List<Appointment> findByName(String name, boolean deleted) {
		return getPersistence().findByName(name, deleted);
	}

	/**
	 * Returns a range of all the appointments where name = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param name the name
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @return the range of matching appointments
	 */
	public static List<Appointment> findByName(
		String name, boolean deleted, int start, int end) {

		return getPersistence().findByName(name, deleted, start, end);
	}

	/**
	 * Returns an ordered range of all the appointments where name = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param name the name
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByName(
		String name, boolean deleted, int start, int end,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().findByName(
			name, deleted, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the appointments where name = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param name the name
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByName(
		String name, boolean deleted, int start, int end,
		OrderByComparator<Appointment> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByName(
			name, deleted, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first appointment in the ordered set where name = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByName_First(
			String name, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByName_First(
			name, deleted, orderByComparator);
	}

	/**
	 * Returns the first appointment in the ordered set where name = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByName_First(
		String name, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByName_First(
			name, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where name = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByName_Last(
			String name, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByName_Last(
			name, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where name = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByName_Last(
		String name, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByName_Last(
			name, deleted, orderByComparator);
	}

	/**
	 * Returns the appointments before and after the current appointment in the ordered set where name = &#63; and deleted = &#63;.
	 *
	 * @param appointmentId the primary key of the current appointment
	 * @param name the name
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next appointment
	 * @throws NoSuchAppointmentException if a appointment with the primary key could not be found
	 */
	public static Appointment[] findByName_PrevAndNext(
			long appointmentId, String name, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByName_PrevAndNext(
			appointmentId, name, deleted, orderByComparator);
	}

	/**
	 * Removes all the appointments where name = &#63; and deleted = &#63; from the database.
	 *
	 * @param name the name
	 * @param deleted the deleted
	 */
	public static void removeByName(String name, boolean deleted) {
		getPersistence().removeByName(name, deleted);
	}

	/**
	 * Returns the number of appointments where name = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param deleted the deleted
	 * @return the number of matching appointments
	 */
	public static int countByName(String name, boolean deleted) {
		return getPersistence().countByName(name, deleted);
	}

	/**
	 * Returns all the appointments where email = &#63; and deleted = &#63;.
	 *
	 * @param email the email
	 * @param deleted the deleted
	 * @return the matching appointments
	 */
	public static List<Appointment> findByEmail(String email, boolean deleted) {
		return getPersistence().findByEmail(email, deleted);
	}

	/**
	 * Returns a range of all the appointments where email = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param email the email
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @return the range of matching appointments
	 */
	public static List<Appointment> findByEmail(
		String email, boolean deleted, int start, int end) {

		return getPersistence().findByEmail(email, deleted, start, end);
	}

	/**
	 * Returns an ordered range of all the appointments where email = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param email the email
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByEmail(
		String email, boolean deleted, int start, int end,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().findByEmail(
			email, deleted, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the appointments where email = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param email the email
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByEmail(
		String email, boolean deleted, int start, int end,
		OrderByComparator<Appointment> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByEmail(
			email, deleted, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first appointment in the ordered set where email = &#63; and deleted = &#63;.
	 *
	 * @param email the email
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByEmail_First(
			String email, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByEmail_First(
			email, deleted, orderByComparator);
	}

	/**
	 * Returns the first appointment in the ordered set where email = &#63; and deleted = &#63;.
	 *
	 * @param email the email
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByEmail_First(
		String email, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByEmail_First(
			email, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where email = &#63; and deleted = &#63;.
	 *
	 * @param email the email
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByEmail_Last(
			String email, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByEmail_Last(
			email, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where email = &#63; and deleted = &#63;.
	 *
	 * @param email the email
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByEmail_Last(
		String email, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByEmail_Last(
			email, deleted, orderByComparator);
	}

	/**
	 * Returns the appointments before and after the current appointment in the ordered set where email = &#63; and deleted = &#63;.
	 *
	 * @param appointmentId the primary key of the current appointment
	 * @param email the email
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next appointment
	 * @throws NoSuchAppointmentException if a appointment with the primary key could not be found
	 */
	public static Appointment[] findByEmail_PrevAndNext(
			long appointmentId, String email, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByEmail_PrevAndNext(
			appointmentId, email, deleted, orderByComparator);
	}

	/**
	 * Removes all the appointments where email = &#63; and deleted = &#63; from the database.
	 *
	 * @param email the email
	 * @param deleted the deleted
	 */
	public static void removeByEmail(String email, boolean deleted) {
		getPersistence().removeByEmail(email, deleted);
	}

	/**
	 * Returns the number of appointments where email = &#63; and deleted = &#63;.
	 *
	 * @param email the email
	 * @param deleted the deleted
	 * @return the number of matching appointments
	 */
	public static int countByEmail(String email, boolean deleted) {
		return getPersistence().countByEmail(email, deleted);
	}

	/**
	 * Returns all the appointments where country = &#63; and deleted = &#63;.
	 *
	 * @param country the country
	 * @param deleted the deleted
	 * @return the matching appointments
	 */
	public static List<Appointment> findByCountry(
		String country, boolean deleted) {

		return getPersistence().findByCountry(country, deleted);
	}

	/**
	 * Returns a range of all the appointments where country = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @return the range of matching appointments
	 */
	public static List<Appointment> findByCountry(
		String country, boolean deleted, int start, int end) {

		return getPersistence().findByCountry(country, deleted, start, end);
	}

	/**
	 * Returns an ordered range of all the appointments where country = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByCountry(
		String country, boolean deleted, int start, int end,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().findByCountry(
			country, deleted, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the appointments where country = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByCountry(
		String country, boolean deleted, int start, int end,
		OrderByComparator<Appointment> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByCountry(
			country, deleted, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first appointment in the ordered set where country = &#63; and deleted = &#63;.
	 *
	 * @param country the country
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByCountry_First(
			String country, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByCountry_First(
			country, deleted, orderByComparator);
	}

	/**
	 * Returns the first appointment in the ordered set where country = &#63; and deleted = &#63;.
	 *
	 * @param country the country
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByCountry_First(
		String country, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByCountry_First(
			country, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where country = &#63; and deleted = &#63;.
	 *
	 * @param country the country
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByCountry_Last(
			String country, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByCountry_Last(
			country, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where country = &#63; and deleted = &#63;.
	 *
	 * @param country the country
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByCountry_Last(
		String country, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByCountry_Last(
			country, deleted, orderByComparator);
	}

	/**
	 * Returns the appointments before and after the current appointment in the ordered set where country = &#63; and deleted = &#63;.
	 *
	 * @param appointmentId the primary key of the current appointment
	 * @param country the country
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next appointment
	 * @throws NoSuchAppointmentException if a appointment with the primary key could not be found
	 */
	public static Appointment[] findByCountry_PrevAndNext(
			long appointmentId, String country, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByCountry_PrevAndNext(
			appointmentId, country, deleted, orderByComparator);
	}

	/**
	 * Removes all the appointments where country = &#63; and deleted = &#63; from the database.
	 *
	 * @param country the country
	 * @param deleted the deleted
	 */
	public static void removeByCountry(String country, boolean deleted) {
		getPersistence().removeByCountry(country, deleted);
	}

	/**
	 * Returns the number of appointments where country = &#63; and deleted = &#63;.
	 *
	 * @param country the country
	 * @param deleted the deleted
	 * @return the number of matching appointments
	 */
	public static int countByCountry(String country, boolean deleted) {
		return getPersistence().countByCountry(country, deleted);
	}

	/**
	 * Returns all the appointments where age = &#63; and deleted = &#63;.
	 *
	 * @param age the age
	 * @param deleted the deleted
	 * @return the matching appointments
	 */
	public static List<Appointment> findByAge(String age, boolean deleted) {
		return getPersistence().findByAge(age, deleted);
	}

	/**
	 * Returns a range of all the appointments where age = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param age the age
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @return the range of matching appointments
	 */
	public static List<Appointment> findByAge(
		String age, boolean deleted, int start, int end) {

		return getPersistence().findByAge(age, deleted, start, end);
	}

	/**
	 * Returns an ordered range of all the appointments where age = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param age the age
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByAge(
		String age, boolean deleted, int start, int end,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().findByAge(
			age, deleted, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the appointments where age = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param age the age
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByAge(
		String age, boolean deleted, int start, int end,
		OrderByComparator<Appointment> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByAge(
			age, deleted, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first appointment in the ordered set where age = &#63; and deleted = &#63;.
	 *
	 * @param age the age
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByAge_First(
			String age, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByAge_First(
			age, deleted, orderByComparator);
	}

	/**
	 * Returns the first appointment in the ordered set where age = &#63; and deleted = &#63;.
	 *
	 * @param age the age
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByAge_First(
		String age, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByAge_First(
			age, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where age = &#63; and deleted = &#63;.
	 *
	 * @param age the age
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByAge_Last(
			String age, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByAge_Last(age, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where age = &#63; and deleted = &#63;.
	 *
	 * @param age the age
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByAge_Last(
		String age, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByAge_Last(
			age, deleted, orderByComparator);
	}

	/**
	 * Returns the appointments before and after the current appointment in the ordered set where age = &#63; and deleted = &#63;.
	 *
	 * @param appointmentId the primary key of the current appointment
	 * @param age the age
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next appointment
	 * @throws NoSuchAppointmentException if a appointment with the primary key could not be found
	 */
	public static Appointment[] findByAge_PrevAndNext(
			long appointmentId, String age, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByAge_PrevAndNext(
			appointmentId, age, deleted, orderByComparator);
	}

	/**
	 * Removes all the appointments where age = &#63; and deleted = &#63; from the database.
	 *
	 * @param age the age
	 * @param deleted the deleted
	 */
	public static void removeByAge(String age, boolean deleted) {
		getPersistence().removeByAge(age, deleted);
	}

	/**
	 * Returns the number of appointments where age = &#63; and deleted = &#63;.
	 *
	 * @param age the age
	 * @param deleted the deleted
	 * @return the number of matching appointments
	 */
	public static int countByAge(String age, boolean deleted) {
		return getPersistence().countByAge(age, deleted);
	}

	/**
	 * Returns all the appointments where name = &#63; and email = &#63; and country = &#63; and age = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param email the email
	 * @param country the country
	 * @param age the age
	 * @param deleted the deleted
	 * @return the matching appointments
	 */
	public static List<Appointment> findByNameEmailCountryAge(
		String name, String email, String country, String age,
		boolean deleted) {

		return getPersistence().findByNameEmailCountryAge(
			name, email, country, age, deleted);
	}

	/**
	 * Returns a range of all the appointments where name = &#63; and email = &#63; and country = &#63; and age = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param name the name
	 * @param email the email
	 * @param country the country
	 * @param age the age
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @return the range of matching appointments
	 */
	public static List<Appointment> findByNameEmailCountryAge(
		String name, String email, String country, String age, boolean deleted,
		int start, int end) {

		return getPersistence().findByNameEmailCountryAge(
			name, email, country, age, deleted, start, end);
	}

	/**
	 * Returns an ordered range of all the appointments where name = &#63; and email = &#63; and country = &#63; and age = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param name the name
	 * @param email the email
	 * @param country the country
	 * @param age the age
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByNameEmailCountryAge(
		String name, String email, String country, String age, boolean deleted,
		int start, int end, OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().findByNameEmailCountryAge(
			name, email, country, age, deleted, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the appointments where name = &#63; and email = &#63; and country = &#63; and age = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param name the name
	 * @param email the email
	 * @param country the country
	 * @param age the age
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByNameEmailCountryAge(
		String name, String email, String country, String age, boolean deleted,
		int start, int end, OrderByComparator<Appointment> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByNameEmailCountryAge(
			name, email, country, age, deleted, start, end, orderByComparator,
			useFinderCache);
	}

	/**
	 * Returns the first appointment in the ordered set where name = &#63; and email = &#63; and country = &#63; and age = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param email the email
	 * @param country the country
	 * @param age the age
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByNameEmailCountryAge_First(
			String name, String email, String country, String age,
			boolean deleted, OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByNameEmailCountryAge_First(
			name, email, country, age, deleted, orderByComparator);
	}

	/**
	 * Returns the first appointment in the ordered set where name = &#63; and email = &#63; and country = &#63; and age = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param email the email
	 * @param country the country
	 * @param age the age
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByNameEmailCountryAge_First(
		String name, String email, String country, String age, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByNameEmailCountryAge_First(
			name, email, country, age, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where name = &#63; and email = &#63; and country = &#63; and age = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param email the email
	 * @param country the country
	 * @param age the age
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByNameEmailCountryAge_Last(
			String name, String email, String country, String age,
			boolean deleted, OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByNameEmailCountryAge_Last(
			name, email, country, age, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where name = &#63; and email = &#63; and country = &#63; and age = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param email the email
	 * @param country the country
	 * @param age the age
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByNameEmailCountryAge_Last(
		String name, String email, String country, String age, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByNameEmailCountryAge_Last(
			name, email, country, age, deleted, orderByComparator);
	}

	/**
	 * Returns the appointments before and after the current appointment in the ordered set where name = &#63; and email = &#63; and country = &#63; and age = &#63; and deleted = &#63;.
	 *
	 * @param appointmentId the primary key of the current appointment
	 * @param name the name
	 * @param email the email
	 * @param country the country
	 * @param age the age
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next appointment
	 * @throws NoSuchAppointmentException if a appointment with the primary key could not be found
	 */
	public static Appointment[] findByNameEmailCountryAge_PrevAndNext(
			long appointmentId, String name, String email, String country,
			String age, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByNameEmailCountryAge_PrevAndNext(
			appointmentId, name, email, country, age, deleted,
			orderByComparator);
	}

	/**
	 * Removes all the appointments where name = &#63; and email = &#63; and country = &#63; and age = &#63; and deleted = &#63; from the database.
	 *
	 * @param name the name
	 * @param email the email
	 * @param country the country
	 * @param age the age
	 * @param deleted the deleted
	 */
	public static void removeByNameEmailCountryAge(
		String name, String email, String country, String age,
		boolean deleted) {

		getPersistence().removeByNameEmailCountryAge(
			name, email, country, age, deleted);
	}

	/**
	 * Returns the number of appointments where name = &#63; and email = &#63; and country = &#63; and age = &#63; and deleted = &#63;.
	 *
	 * @param name the name
	 * @param email the email
	 * @param country the country
	 * @param age the age
	 * @param deleted the deleted
	 * @return the number of matching appointments
	 */
	public static int countByNameEmailCountryAge(
		String name, String email, String country, String age,
		boolean deleted) {

		return getPersistence().countByNameEmailCountryAge(
			name, email, country, age, deleted);
	}

	/**
	 * Returns all the appointments where groupId = &#63; and deleted = &#63;.
	 *
	 * @param groupId the group ID
	 * @param deleted the deleted
	 * @return the matching appointments
	 */
	public static List<Appointment> findByGroupId(
		long groupId, boolean deleted) {

		return getPersistence().findByGroupId(groupId, deleted);
	}

	/**
	 * Returns a range of all the appointments where groupId = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @return the range of matching appointments
	 */
	public static List<Appointment> findByGroupId(
		long groupId, boolean deleted, int start, int end) {

		return getPersistence().findByGroupId(groupId, deleted, start, end);
	}

	/**
	 * Returns an ordered range of all the appointments where groupId = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByGroupId(
		long groupId, boolean deleted, int start, int end,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().findByGroupId(
			groupId, deleted, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the appointments where groupId = &#63; and deleted = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param deleted the deleted
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching appointments
	 */
	public static List<Appointment> findByGroupId(
		long groupId, boolean deleted, int start, int end,
		OrderByComparator<Appointment> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByGroupId(
			groupId, deleted, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first appointment in the ordered set where groupId = &#63; and deleted = &#63;.
	 *
	 * @param groupId the group ID
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByGroupId_First(
			long groupId, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByGroupId_First(
			groupId, deleted, orderByComparator);
	}

	/**
	 * Returns the first appointment in the ordered set where groupId = &#63; and deleted = &#63;.
	 *
	 * @param groupId the group ID
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByGroupId_First(
		long groupId, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByGroupId_First(
			groupId, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where groupId = &#63; and deleted = &#63;.
	 *
	 * @param groupId the group ID
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment
	 * @throws NoSuchAppointmentException if a matching appointment could not be found
	 */
	public static Appointment findByGroupId_Last(
			long groupId, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByGroupId_Last(
			groupId, deleted, orderByComparator);
	}

	/**
	 * Returns the last appointment in the ordered set where groupId = &#63; and deleted = &#63;.
	 *
	 * @param groupId the group ID
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching appointment, or <code>null</code> if a matching appointment could not be found
	 */
	public static Appointment fetchByGroupId_Last(
		long groupId, boolean deleted,
		OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().fetchByGroupId_Last(
			groupId, deleted, orderByComparator);
	}

	/**
	 * Returns the appointments before and after the current appointment in the ordered set where groupId = &#63; and deleted = &#63;.
	 *
	 * @param appointmentId the primary key of the current appointment
	 * @param groupId the group ID
	 * @param deleted the deleted
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next appointment
	 * @throws NoSuchAppointmentException if a appointment with the primary key could not be found
	 */
	public static Appointment[] findByGroupId_PrevAndNext(
			long appointmentId, long groupId, boolean deleted,
			OrderByComparator<Appointment> orderByComparator)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByGroupId_PrevAndNext(
			appointmentId, groupId, deleted, orderByComparator);
	}

	/**
	 * Removes all the appointments where groupId = &#63; and deleted = &#63; from the database.
	 *
	 * @param groupId the group ID
	 * @param deleted the deleted
	 */
	public static void removeByGroupId(long groupId, boolean deleted) {
		getPersistence().removeByGroupId(groupId, deleted);
	}

	/**
	 * Returns the number of appointments where groupId = &#63; and deleted = &#63;.
	 *
	 * @param groupId the group ID
	 * @param deleted the deleted
	 * @return the number of matching appointments
	 */
	public static int countByGroupId(long groupId, boolean deleted) {
		return getPersistence().countByGroupId(groupId, deleted);
	}

	/**
	 * Caches the appointment in the entity cache if it is enabled.
	 *
	 * @param appointment the appointment
	 */
	public static void cacheResult(Appointment appointment) {
		getPersistence().cacheResult(appointment);
	}

	/**
	 * Caches the appointments in the entity cache if it is enabled.
	 *
	 * @param appointments the appointments
	 */
	public static void cacheResult(List<Appointment> appointments) {
		getPersistence().cacheResult(appointments);
	}

	/**
	 * Creates a new appointment with the primary key. Does not add the appointment to the database.
	 *
	 * @param appointmentId the primary key for the new appointment
	 * @return the new appointment
	 */
	public static Appointment create(long appointmentId) {
		return getPersistence().create(appointmentId);
	}

	/**
	 * Removes the appointment with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param appointmentId the primary key of the appointment
	 * @return the appointment that was removed
	 * @throws NoSuchAppointmentException if a appointment with the primary key could not be found
	 */
	public static Appointment remove(long appointmentId)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().remove(appointmentId);
	}

	public static Appointment updateImpl(Appointment appointment) {
		return getPersistence().updateImpl(appointment);
	}

	/**
	 * Returns the appointment with the primary key or throws a <code>NoSuchAppointmentException</code> if it could not be found.
	 *
	 * @param appointmentId the primary key of the appointment
	 * @return the appointment
	 * @throws NoSuchAppointmentException if a appointment with the primary key could not be found
	 */
	public static Appointment findByPrimaryKey(long appointmentId)
		throws com.liferay.hms.appointment.exception.
			NoSuchAppointmentException {

		return getPersistence().findByPrimaryKey(appointmentId);
	}

	/**
	 * Returns the appointment with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param appointmentId the primary key of the appointment
	 * @return the appointment, or <code>null</code> if a appointment with the primary key could not be found
	 */
	public static Appointment fetchByPrimaryKey(long appointmentId) {
		return getPersistence().fetchByPrimaryKey(appointmentId);
	}

	/**
	 * Returns all the appointments.
	 *
	 * @return the appointments
	 */
	public static List<Appointment> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the appointments.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @return the range of appointments
	 */
	public static List<Appointment> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the appointments.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of appointments
	 */
	public static List<Appointment> findAll(
		int start, int end, OrderByComparator<Appointment> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the appointments.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>AppointmentModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of appointments
	 * @param end the upper bound of the range of appointments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of appointments
	 */
	public static List<Appointment> findAll(
		int start, int end, OrderByComparator<Appointment> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Removes all the appointments from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of appointments.
	 *
	 * @return the number of appointments
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static AppointmentPersistence getPersistence() {
		return _persistence;
	}

	private static volatile AppointmentPersistence _persistence;

}